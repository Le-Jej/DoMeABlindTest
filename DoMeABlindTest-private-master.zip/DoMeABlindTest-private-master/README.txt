## Licence

Ce logiciel est distribué sous les termes de la **GNU GPL version 3**.

Vous pouvez consulter le texte complet de la licence dans le fichier [LICENSE](./LICENSE) ou sur le site de la Free Software Foundation :  
[https://www.gnu.org/licenses/gpl-3.0.html](https://www.gnu.org/licenses/gpl-3.0.html)


v1 du générateur de blind test

But du programme : 
A partir d'un dossier : prendre tout les fichier audio (.mp3, .wav) et créer -> un dossier avec tous les audio dans un ordre randomisé (dossier \Réponse)
									  										 -> un dossier avec les extrait anonymisé dans le même ordre que le dossier \Réponse (dossier \BT)


!!! Attention !!! 
si les dossier \Réponse et \BT existe déjà, il seront supprimer dans le process.
